package com.example.springaopex.aop;


import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class LoggingAspect {
    Logger log = LoggerFactory.getLogger(this.getClass());

//    @Before("com.example.springaopex.aop.PointCuts.thisImpl2()")
//    public void thisImpl2BeforeAdvice(JoinPoint joinPoint){
//        log.info("this Impl2 before advice: " + joinPoint.getSignature());
//    }
//
//    @Before("com.example.springaopex.aop.PointCuts.targetUserDAO()")
//    public void targetUserDAOBeforeAdvice(JoinPoint joinPoint){
//        log.info("target UserDAO before advice: " + joinPoint.getSignature());
//    }


//    @Around("com.example.springaopex.aop.PointCuts.inDataAccessLayer()")
//    public Object executionTimeAdvice(ProceedingJoinPoint pjp) throws Throwable {
//        long startTime = System.currentTimeMillis();
//        String className = pjp.getSignature().getDeclaringTypeName();
//        String methodName = pjp.getSignature().getName();
//        System.out.println("before processed");
//        Object result = pjp.proceed();
//        long elapsedTime = System.currentTimeMillis() - startTime;
//
//        System.out.println("ClassName: "+className);
//        System.out.println("MethodName: "+methodName);
//        System.out.println("Result: "+result);
//
//        log.info(className+"."+methodName+" execution time: "+elapsedTime+" ms");
//        return result;
//    }


//    @Before("com.example.springaopex.aop.PointCuts.methodStartsWithFind()")
//    public void methodStartsWithFindBeforeAdvice(JoinPoint joinPoint){
//        log.info("methodStartsWithFind Before Advice: "+ joinPoint.getSignature());
//    }
//
//    @Before("com.example.springaopex.aop.PointCuts.argsPassAtRuntimeIsSerializable()")
//    public void argsPassAtRuntimeIsSerializableBeforeAdvice(JoinPoint joinPoint){
//        log.info("argsPassAtRuntimeIsSerializableBeforeAdvice Before Advice: "+ joinPoint.getSignature());
//    }

//    @After("com.example.springaopex.aop.PointCuts.inBeanWithSuffixController()")
//    public void inBeanWithSuffixControllerAfterAdvice(JoinPoint joinPoint){
//        log.info("After Advice: "+ joinPoint.getSignature());
//    }
//
//
//    @After("com.example.springaopex.aop.PointCuts.inBeanWithSuffixService()")
//    public void inBeanWithSuffixServiceAfterAdvice(JoinPoint joinPoint){
//        log.info("After Advice: "+ joinPoint.getSignature());
//    }

//    @After("com.example.springaopex.aop.PointCuts.ObjectHasAnnotationOfService()")
//    public void ObjectHasAnnotationOfServiceAfterAdvice(JoinPoint joinPoint){
//        log.info("After Advice: "+ joinPoint.getSignature());
//    }

//
    @AfterReturning(value = "com.example.springaopex.aop.PointCuts.methodWithinClassWithAnnotationRestController()", returning = "res")
    public void afterReturningAdvice(Object res){
        log.info("After Returning: " + res.toString());
    }

    @After("com.example.springaopex.aop.PointCuts.methodWithAnnotationExceptionHandler()")
    public void AfterMethodWithAnnotationExceptionHandler(JoinPoint joinPoint) {
        log.info("After Advice MethodWithAnnotationExceptionHandler: " + joinPoint.getSignature());
    }

    @After("com.example.springaopex.aop.PointCuts.methodWithinClassWithAnnotationRestController()")
    public void AfterMethodWithinClassWithAnnotationRestController(JoinPoint joinPoint){
        log.info("After Advice MethodWithinClassWithAnnotationRestController: " + joinPoint.getSignature());
    }


    @AfterThrowing("com.example.springaopex.aop.PointCuts.methodWithinClassWithAnnotationRestController()")
    public void afterThrowing(JoinPoint joinPoint){
        log.info("After Throwing: " + joinPoint.getSignature());
    }

}
