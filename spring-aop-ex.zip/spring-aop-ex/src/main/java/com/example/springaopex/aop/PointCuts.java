package com.example.springaopex.aop;


import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

import javax.annotation.PostConstruct;

@Aspect
public class PointCuts {
    /*
    The primary Spring PCD is execution, which matches method execution join points.
     */
    @Pointcut("execution(* find*(..))")
    public void methodStartsWithFind() {}

    /*
    Another way to achieve the same result from the previous section is by using the within PCD,
    which limits matching to join points of certain types.
     */
    @Pointcut("within(com.example.springaopex.dao..*)")
    public void inDataAccessLayer() {}

    /*
    this limits matching to join points where the bean reference is an instance of the given type,
    while target limits matching to join points where the target object is an instance of the given type.
    The former works when Spring AOP creates a CGLIB-based proxy, and the latter is used when a JDK-based proxy is created
     */
    @Pointcut("this(com.example.springaopex.dao.UserDAO)")
    public void thisImpl2(){}

    @Pointcut("target(com.example.springaopex.dao.UserDAO)")
    public void targetUserDAO(){}

    /*
    This PCD is used for matching particular method arguments
     */
//    @Pointcut("within(com.example.springaopex..*)&&args(java.io.Serializable)")
//    public void argsPassAtRuntimeIsSerializable(){}

    /*
    Limit the matching of join points to a particular named Spring bean or to a set of named Spring beans
     */
    @Pointcut("bean(*Controller)")
    public void inBeanWithSuffixController() {}

    @Pointcut("bean(*Service)")
    public void inBeanWithSuffixService() {}

    /*
    The @target PCD (not to be confused with the target PCD described above) limits matching to join points
    where the class of the executing object has an annotation of the given type:
     */
    @Pointcut("within(com.example.springaopex..*)&&@target(org.springframework.stereotype.Service)")
    public void ObjectHasAnnotationOfService(){}


    /*
    This PCD limits matching to join points within types that have the given annotation:
     */
    @Pointcut("@within(org.springframework.web.bind.annotation.RestController)")
    public void methodWithinClassWithAnnotationRestController() {}


    /*
    This PCD limits matching to join points where the subject of the join point has the given annotation.
     */
    @Pointcut("@annotation(org.springframework.web.bind.annotation.ExceptionHandler)")
    public void methodWithAnnotationExceptionHandler() {}

}
