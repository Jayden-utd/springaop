package com.example.springaopex.controller;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.CodeSignature;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.lang.reflect.Method;

/**
 * @Description:
 * @author: Jayden
 * @date:8/31/21 9:58 PM
 */
@Component
@Aspect
public class GetRequestLogger {
    @Pointcut("@annotation(org.springframework.web.bind.annotation.GetMapping)")
    public void getAction() {
    }

    @Before("getAction()")
    public void logAction(JoinPoint joinPoint) {
        Class clazz = joinPoint.getTarget().getClass();
        Logger logger = LoggerFactory.getLogger(clazz);

        String url = getRequestUrl(joinPoint, clazz);
        String payload = getPayload(joinPoint);
        logger.info("GET " + url + " Payload " + payload);
    }

    private String getRequestUrl(JoinPoint joinPoint, Class clazz) {
        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
        Method method = methodSignature.getMethod();
        GetMapping methodGetMapping = method.getAnnotation(GetMapping.class);
        RequestMapping requestMapping = (RequestMapping) clazz.getAnnotation(RequestMapping.class);
        return getGetUrl(requestMapping, methodGetMapping);
    }

    private String getPayload(JoinPoint joinPoint) {
        CodeSignature signature = (CodeSignature) joinPoint.getSignature();
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < joinPoint.getArgs().length; i++) {
            String parameterName = signature.getParameterNames()[i];
            builder.append(parameterName);
            builder.append(": ");
            builder.append(joinPoint.getArgs()[i].toString());
            builder.append(", ");
        }
        return builder.toString();
    }

    private String getGetUrl(RequestMapping requestMapping, GetMapping getMapping) {
        String baseUrl = getUrl(requestMapping.value());
        String endpoint = getUrl(getMapping.value());

        return baseUrl + endpoint;
    }

    private String getUrl(String[] urls) {
        if (urls.length == 0) return "";
        else return urls[0];
    }
}
