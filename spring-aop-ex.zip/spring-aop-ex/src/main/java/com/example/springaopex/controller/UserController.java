package com.example.springaopex.controller;

import com.example.springaopex.domain.UserResponse;
import com.example.springaopex.exception.UserNotFoundException;
import com.example.springaopex.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {
    @Autowired
    private UserService userService;

    @GetMapping("/user")
    public ResponseEntity<UserResponse> findAll(){
        UserResponse userResponse = UserResponse.builder().userList(userService.findAll()).build();
        return new ResponseEntity<>(userResponse, HttpStatus.OK);
    }

    @GetMapping("/user/{name}")
    public ResponseEntity findByName(@PathVariable String name) throws UserNotFoundException {
        UserResponse userResponse = UserResponse.builder().userList(userService.findByName(name)).build();
        return new ResponseEntity<>(userResponse,HttpStatus.OK);
    }


    @GetMapping("/user2")
    public ResponseEntity<UserResponse> findAll2(){
        UserResponse userResponse = UserResponse.builder().userList(userService.findAll2()).build();
        return new ResponseEntity<>(userResponse, HttpStatus.OK);
    }

    @GetMapping("/user2/{name}")
    public ResponseEntity findByName2(@PathVariable String name) throws UserNotFoundException {
        UserResponse userResponse = UserResponse.builder().userList(userService.findByName2(name)).build();
        return new ResponseEntity<>(userResponse,HttpStatus.OK);
    }



}
