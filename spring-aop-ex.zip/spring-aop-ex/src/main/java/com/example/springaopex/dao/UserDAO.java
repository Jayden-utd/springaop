package com.example.springaopex.dao;

import com.example.springaopex.domain.User;

import java.util.List;
import java.util.Collection;

public interface UserDAO {
    public List<User> findAll();

    public List<User> findByName(String name);
}
