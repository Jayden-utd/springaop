package com.example.springaopex.service;
import com.example.springaopex.aop.TrackExecutionTime;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
/**
 * @Description:
 * @author: Jayden
 * @date:8/31/21 9:06 PM
 */
@Service
@Slf4j
public class EmployeeService {

    @TrackExecutionTime
    public String getEmployeeNameFromId(String id){
        return "Test Name From Service";
    }
}
