package com.example.springaopex.service;


import com.example.springaopex.dao.UserDAOImpl1;
import com.example.springaopex.dao.UserDAOImpl2;
import com.example.springaopex.domain.User;
import com.example.springaopex.exception.UserNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {
    @Autowired
    private UserDAOImpl1 userDAOImpl1;

    @Autowired
    private UserDAOImpl2 userDAOImpl2;

    public List<User> findAll(){
        return userDAOImpl1.findAll();
    }

    public List<User> findByName(String name) throws UserNotFoundException {
        List<User> res = userDAOImpl1.findByName(name);
        if(res.isEmpty()){
            throw new UserNotFoundException(name);
        }
        return res;
    };

    public List<User> findAll2(){
        return userDAOImpl2.findAll();
    }

    public List<User> findByName2(String name) throws UserNotFoundException {
        List<User> res = userDAOImpl2.findByName(name);
        if(res.isEmpty()){
            throw new UserNotFoundException(name);
        }
        return res;
    };
}
