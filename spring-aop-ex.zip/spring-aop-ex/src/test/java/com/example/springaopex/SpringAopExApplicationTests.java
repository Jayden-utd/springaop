package com.example.springaopex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAopExApplicationTests {

    @Test
    void contextLoads() {
    }

}
